<?php include "inc/header.php" ?>
<?php
	$login = Session::get("cusLogin");
	if($login==false){
		header('location:login.php');
	}
?>
<?php
	if(isset($_GET['orderid']) && $_GET['orderid']=='order'){
		$cusId = Session::get("cusId");
		$insertOrder = $ct->insetOrderByCusId($cusId);
		$delcart = $ct->delCusBySession();
		header("location:success.php");
	}
?>

<style>
.tblone{width:450px;margin:0 auto;border:2px solid #ddd;}
.tblone tr td{text-align:justify;}
input[type="text"]{padding:5px 10px;}
tblone.input[type="submit"]{padding:5px 10px;}
.cartpage{float:left;width:500px;}
.user{float:right;width:500px;}
.order a{background: #ff0000 none repeat scroll 0 0;color: #fff;display: block;font-size: 25px; margin: 10px auto; padding: 3px 50px;text-align: center; border-radius: 15px;width: 150px;}
</style>
<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$cartId    = $_POST['cartId'];
		$quantity  = $_POST['quantity'];
		if($quantity <= '0'){
			$msg = "<span class='error'>Please enter a value greater than zero...!</span>";
		}else{
			$updateCart   = $ct->updateCartQuan($quantity,$cartId);
		}
	}
?>
<?php
	if(isset($_GET['delcartid'])){
		$id = preg_replace('/[^-a-zA-Z0-9_]/','', $_GET['delcartid']);
		$delcart = $ct->delCartById($id);
	}
?>
<?php if(!isset($_GET['id']))
	echo "<meta http-equiv='refresh' content='0;URL=?id=Sumon'>";
?>
 <div class="main">
    <div class="content">
    	<div class="cartoption">
			<div class="cartpage">
			    	<h2>Your Cart</h2>
			    	
			    	<?php if(isset($updateCart)){
			    		echo $updateCart; }
			    		if(isset($delcart)){
			    		echo $delcart; 
			    		}
			    		if(isset($msg)){
			    		echo $msg; 
			    		}?>
			    	
						<table class="tblone">
							<tr>
								<th>No</th>
								<th>Product</th>
								<th >Price</th>
								<th>Quantity</th>
								<th>Total</th>
							</tr>
							<?php
							global $sum;
								$getCart = $ct->getCartInfo();
								if($getCart){
									$i = 0;
									$sum = 0;
									while($data = $getCart->fetch_assoc()){
										$i++;
							?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $data['productName'];?></td>
								<td><?php echo $data['price'];?></td>
								<td><?php echo $data['quantity'];?></td>
								<td>
									<?php
										 $total = $data['price'] * $data['quantity'];
										 echo $total;
									?>
										
								</td>
							</tr>
							<?php  $sum = $sum+$total; ?>
						 <?php }}?>
						</table>
						<?php
							$checkemptycart =$ct->getCartInfo();
							if($checkemptycart){
						?>
						<table style="float:right;margin:10px 50px 10px 0px">
							<tr>
								<th>Sub Total : </th>
								<td><?php echo $sum;?></td>	
							</tr>
							<tr>
								<th>VAT : 10%</th>
								<td>10%</td>
							</tr>
							<tr>
								<th>Grand Total :</th>
								<td><?php
										 $vat = $sum * 0.1;
										$withvat = $vat+$sum;
										echo $withvat;
										Session::set("sum","$withvat");
									 ?>
								</td>
							</tr>
					   </table>
							<?php }else{?>
								<span class='error'>Your cart is empty please buy now...!</span>;
							<?php }?>
					</div>
	<div class="user">
    	<?php 
    		$customerId = Session::get("cusId");
    		$checkCusId = $cus->getCusById($customerId);
    		if($checkCusId){
    			while($result = $checkCusId ->fetch_assoc()){?>
			<table class="tblone">
				<tr>
					<td width="20%">Name</td>
					<td width="5%">:</td>
					<td><?php echo $result['name'];?></td>
				</tr>
				<tr>
					<td>Email</td>
					<td>:</td>
					<td><?php echo $result['e_mail'];?></td>
				</tr>
				<tr>
					<td>Phone</td>
					<td>:</td>
					<td><?php echo $result['phone'];?></td>
				</tr>
				<tr>
					<td>Address</td>
					<td>:</td>
					<td><?php echo $result['address'];?></td>
				</tr>
				<tr>
					<td>Zip-code</td>
					<td>:</td>
					<td><?php echo $result['zip_code'];?></td>
				</tr>
				<tr>
					<td>City</td>
					<td>:</td>
					<td><?php echo $result['city'];?></td>
				</tr>
				<tr>
					<td>Country</td>
					<td>:</td>
					<td><?php echo $result['country'];?></td>
				</tr>
				<tr>
					<td>Action</td>
					<td>:</td>
					<td><a href="editprofile.php">Edit profile</a></td>
				</tr>	
			</table>	
			<?php  }} ?>
 		</div>
 	</div>
       <div class="clear"></div>
    </div>
    	<div class="order">
    		<a href="?orderid=order">Order</a>
    	</div>
</div>
   <?php include "inc/footer.php"?>