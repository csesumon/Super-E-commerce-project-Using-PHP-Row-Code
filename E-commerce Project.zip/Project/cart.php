<?php include "inc/header.php" ?>

<?php
	if($_SERVER['REQUEST_METHOD']=='POST'){
		$cartId    = $_POST['cartId'];
		$quantity  = $_POST['quantity'];
		if($quantity <= '0'){
			$msg = "<span class='error'>Please enter a value greater than zero...!</span>";
		}else{
			$updateCart   = $ct->updateCartQuan($quantity,$cartId);
		}
	}
?>
<?php
	if(isset($_GET['delcartid'])){
		$id = preg_replace('/[^-a-zA-Z0-9_]/','', $_GET['delcartid']);
		$delcart = $ct->delCartById($id);
	}
?>
<?php if(!isset($_GET['id']))
	echo "<meta http-equiv='refresh' content='0;URL=?id=Sumon'>";
?>
 <div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">
			    	<h2>Your Cart</h2>
			    	
			    	<?php if(isset($updateCart)){
			    		echo $updateCart; }
			    		if(isset($delcart)){
			    		echo $delcart; 
			    		}
			    		if(isset($msg)){
			    		echo $msg; 
			    		}?>
			    	
						<table class="tblone">
							<tr>
								<th width="10%">Sl No</th>
								<th width="30%">Product Name</th>
								<th width="10%">Image</th>
								<th width="15%">Price</th>
								<th width="20%">Quantity</th>
								<th width="15%">Total Price</th>
								<th width="10%">Action</th>
							</tr>
							<?php
							global $sum;
								$getCart = $ct->getCartInfo();
								if($getCart){
									$i = 0;
									$sum = 0;
									while($data = $getCart->fetch_assoc()){
										$i++;
							?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $data['productName'];?></td>
								<td><img src="admin/<?php echo $data['image'];?>" alt=""/></td>
								<td><?php echo $data['price'];?></td>
								
								<td>
									<form action="" method="post">
										<input type="hidden" name="cartId" value="<?php echo $data['cartId'];?>"/>
										<input type="number" name="quantity" value="<?php echo $data['quantity'];?>"/>
										<input type="submit" name="submit" value="Update"/>
									</form>
								</td>
								<td>
									<?php
										 $total = $data['price'] * $data['quantity'];
										 echo $total;
									?>
										
								</td>
								<td><a onclick ="return confirm('Are you sure to delete.')" href="?delcartid=<?php echo $data['cartId'];?>">X</a></td>
							</tr>
							<?php  $sum = $sum+$total; ?>
						 <?php }}?>
						</table>
						<?php
							$checkemptycart =$ct->getCartInfo();
							if($checkemptycart){
						?>
						<table style="float:right;text-align:left;" width="40%">
							<tr>
								<th>Sub Total : </th>
								<td><?php echo $sum;?></td>	
							</tr>
							<tr>
								<th>VAT : 10%</th>
								<td>10%</td>
							</tr>
							<tr>
								<th>Grand Total :</th>
								<td><?php
										 $vat = $sum * 0.1;
										$withvat = $vat+$sum;
										echo $withvat;
										Session::set("sum","$withvat");
									 ?>
								</td>
							</tr>
					   </table>
							<?php }else{?>
								<span class='error'>Your cart is empty please buy now...!</span>;
							<?php }?>
					</div>
					<div class="shopping">
						<div class="shopleft">
							<a href="index.php"> <img src="images/shop.png" alt="" /></a>
						</div>
						<div class="shopright">
							<a href="payment.php"> <img src="images/check.png" alt="" /></a>
						</div>
					</div>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
</div>
   <?php include "inc/footer.php"?>