<?php include "inc/header.php" ?>
 <div class="main">
 <style>
 	.notfound h2{color:red;font-size:130px;text-align: center;line-height: 100px}
 	.notfound h2 span{color:#ddd;font-size:80px;text-align: center;display:block;}

 </style>
    <div class="content">
    	<div class="notfound">	
    	<h2>404<span>NOT FOUND</span></h2>
			
   	 </div>
 </div>
</div>
   <?php include "inc/footer.php"?>