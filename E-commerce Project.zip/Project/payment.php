<?php include "inc/header.php" ?>
<?php
	$login = Session::get("cusLogin");
	if($login==false){
		header('location:login.php');
	}
?>
<style>
.Payment{width:500px; margin: 0 auto; padding:50px 100px;border: 2px solid #ccc;text-align: center;min-height: 130px}
.Payment h2 { border-bottom: 1px solid #000; color: #6c6c6c; font-family: "Monda",sans-serif; font-size: 25px;margin-bottom: 30px;}
.Payment a {background: #ff0000 none repeat scroll 0 0;font-size: 20px;padding: 10px;text-align: center;text-decoration: none;color: #fff;
}
.back a {background: #3399ff none repeat scroll 0 0;color: #fff;display: block;font-size: 20px;margin: 10px auto;padding: 9px 0px;text-align: center;text-decoration: none;width: 100px;box-shadow: 4px 7px 3px #000;
}

</style>
 <div class="main">
    <div class="content">
    	<div class="section group">
			<div class="Payment">
				<h2>Chose payment option</h2>
				<a href="offline.php">Offline Payment</a>
				<a href="online.php">Online Payment</a>
			</div>
			<div class="back">
				<a href="cart.php">Previous</a>
			</div>				
 		</div>
 	</div>
</div>
<?php include "inc/footer.php"?>