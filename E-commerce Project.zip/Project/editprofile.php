<?php include "inc/header.php" ?>
<?php
	$login = Session::get("cusLogin");
	if($login==false){
		header('location:login.php');
	}
?>
<style>
.tblone{width:550px;margin:0 auto;border:2px solid #ddd;}
.tblone tr td{text-align:justify;}
input[type="text"]{padding:5px 10px;}
tblone.input[type="submit"]{padding:5px 10px;}
</style>
 <div class="main">
    <div class="content">
    	<div class="section group">
    <?php
	    if($_SERVER["REQUEST_METHOD"]=="POST"){
	        $updateProfile = $cus->updateProfle($_POST);
	    }
	?>
    	<?php 
    		$customerId = Session::get("cusId");
    		$checkCusId = $cus->getCusById($customerId);
    		if($checkCusId){
    			while($result = $checkCusId ->fetch_assoc()){?>
    	<form action="" method="post">
			<table class="tblone">
				<tr>
					<td colspan="3"><?php if(isset($updateProfile)){
					echo $updateProfile;}?></td>
				</tr>
				<tr>
					<td colspan="3">Your Profile Details</td>
				</tr>
				<tr>
					<td>Name</td>
					<td><input type="text" name="name" value="<?php echo $result['name'];?>"/></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="e_mail" value="<?php echo $result['e_mail'];?>"/></td>
				</tr>
				<tr>
					<td>Phone</td>
					<td><input type="text" name="phone" value="<?php echo $result['phone'];?>"/></td>
				</tr>
				<tr>
					<td>Address</td>
					<td><input type="text" name="address" value="<?php echo $result['address'];?>"/></td>
				</tr>
				<tr>
					<td>Zip-code</td>
					<td><input type="text" name="zip_code" value="<?php echo $result['zip_code'];?>"/></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" value="<?php echo $result['city'];?>"/></td>
				</tr>
				<tr>
					<td>Country</td>
					<td><input type="text" name="country" value="<?php echo $result['country'];?>"/></td>
				</tr>
				<tr>
					<td>Action</td>
					<td><input type="submit" name="submit" value="Update"/></td>
				</tr>	
			</table>
		</form>	
			<?php  }} ?>
 		</div>
 	</div>
</div>
   <?php include "inc/footer.php" ?>
