<?php include "inc/header.php" ?>
<?php
	$login = Session::get("cusLogin");
	if($login==false){
		header('location:login.php');
	}
?>
<?php  
	if(isset($_GET['upshiftedid'])){
		$id = $_GET['upshiftedid'];
		$price = $_GET['price'];
		$time = $_GET['time'];
		$updateStatusFrond = $ct->updateStatusByIdFrond($id,$price,$time);
	}
?>
<div class="main">
    <div class="content">
    	<div class="section group">
    		<div class="order">
    		<h2>Your Order Details</h2>
    		<table class="tblone">
							<tr>
								<th>No</th>
								<th>Product Name</th>
								<th>Image</th>
								<th>Price</th>
								<th>Quantity</th>
								<th>Date</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
							<?php
								$customerId = Session::get("cusId");
								$getOrder = $ct->getOrderInfo($customerId);
								if($getOrder){
									$i = 0;
									while($data = $getOrder->fetch_assoc()){
										$i++;
							?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $data['productName'];?></td>
								<td><img src="admin/<?php echo $data['image'];?>" alt=""/></td>
								<td><?php echo $data['price'];?></td>
								<td><?php echo $data['quantity'];?></td>
								<td><?php echo $fm->formatDate($data['date'])?></td>
								<td>
								<?php
									if($data['status']=='0'){ echo "Pending"; ?>
									<?php }elseif($data['status']=='1'){?>
										<a href="?upshiftedid=<?php echo $data['cusId'];?> & price=<?php echo $data['price'];?> & time=<?php echo $data['date'];?>">Shifted</a>
									<?php }else{
										echo "Confirm";
									}
								?>
								</td>
								<td>
									<?php
										if($data['status']==1){?>
											<a onclick ="return confirm('Are you sure to delete.')" href="">X</a>
									<?php } else{ echo "N/A";}?>
								</td>
							</tr>
						 <?php }}?>
						</table>
    		</div>	
    	</div>
    	  <div class="clear"></div>
    </div>
</div>
<?php include "inc/footer.php" ?>

