<?php
	$filepath = realpath(dirname(__FILE__));
		include_once ($filepath."/../lib/Database.php");
		include_once ($filepath."/../helpers/Format.php");
?>

<?php
	Class Product{
		private $db;
		private $fm;

		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function productInsert($data,$file){
			$productName = $this->fm->validation($data['productName']);
			$productName = mysqli_escape_string($this->db->link,$productName);
			$catId = $this->fm->validation($data['catId']);
			$catId = mysqli_escape_string($this->db->link,$catId);
			$brandId = $this->fm->validation($data['brandId']);
			$brandId = mysqli_escape_string($this->db->link,$brandId);
			$body = $this->fm->validation($data['body']);
			$body = mysqli_escape_string($this->db->link,$body);
			$price = $this->fm->validation($data['price']);
			$price = mysqli_escape_string($this->db->link,$price);
			$type = $this->fm->validation($data['type']);
			$type = mysqli_escape_string($this->db->link,$type);

			if ($_SERVER["REQUEST_METHOD"] == "POST") {
		    $permited  = array('jpg', 'jpeg', 'png', 'gif');
		    $file_name = $_FILES['image']['name'];
		    $file_size = $_FILES['image']['size'];
		    $file_temp = $_FILES['image']['tmp_name'];

		    $div = explode('.', $file_name);
		    $file_ext = strtolower(end($div));
		    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
		    $uploaded_image = "uploads/".$unique_image;
		    if($productName =="" || $catId =="" || $brandId=="" || $body =="" || $price =="" || $file_name=="" || $type =="" ){
		    	$msg = "<span class='error'>Field must not be empty...!</span>";
					return $msg;
		    }elseif ($file_size >1048567) {
		      echo "<span class='error'>Image Size should be less then 1MB!
		     </span>";
		    } elseif (in_array($file_ext, $permited) === false) {
		      echo "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
		    }
		    else{
		    	  move_uploaded_file($file_temp, $uploaded_image);
		    	 $query = "INSERT INTO tbl_product(productName,catId,brandId,body,price,image,type) VALUES ('$productName','$catId','$brandId','$body','$price','$uploaded_image','$type') ";
				$productInsert = $this->db->insert($query);
				if($productInsert){
					$msg = "<span class='success'>product Inserted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>product Not Inserted...!</span>";
					return $msg;
				}
		    }

		}
	}
	public function getAllProduct(){
		$query = "SELECT p.*,b.brandName,c.catName FROM
			tbl_product as p,tbl_brand AS b,tbl_category AS c WHERE 
			p.brandId = b.brandId AND p.catId = c.catId ORDER BY p.productId DESC";
		/*
		$query = "SELECT tbl_product.*, tbl_brand.brandName, tbl_category.catName 
		FROM tbl_product 
		INNER JOIN tbl_brand 
		ON tbl_product.brandId = tbl_brand.brandId
		INNER JOIN tbl_category 
		ON tbl_product.catId = tbl_category.catId
		ORDER BY tbl_product.productId DESC";
		*/
		$getProduct = $this->db->select($query);
		return $getProduct;
	}
	public function getProById($id){
		$query = "SELECT * FROM tbl_product WHERE productId='$id' ";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function productUpdate($data,$file,$id){
		$productName = $this->fm->validation($data['productName']);
			$productName = mysqli_escape_string($this->db->link,$productName);
			$catId = $this->fm->validation($data['catId']);
			$catId = mysqli_escape_string($this->db->link,$catId);
			$brandId = $this->fm->validation($data['brandId']);
			$brandId = mysqli_escape_string($this->db->link,$brandId);
			$body = $this->fm->validation($data['body']);
			$body = mysqli_escape_string($this->db->link,$body);
			$price = $this->fm->validation($data['price']);
			$price = mysqli_escape_string($this->db->link,$price);
			$type = $this->fm->validation($data['type']);
			$type = mysqli_escape_string($this->db->link,$type);

			if ($_SERVER["REQUEST_METHOD"] == "POST") {
		    $permited  = array('jpg', 'jpeg', 'png', 'gif');
		    $file_name = $_FILES['image']['name'];
		    $file_size = $_FILES['image']['size'];
		    $file_temp = $_FILES['image']['tmp_name'];

		    $div = explode('.', $file_name);
		    $file_ext = strtolower(end($div));
		    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
		    $uploaded_image = "uploads/".$unique_image;
		    if($productName =="" || $catId =="" || $brandId=="" || $body =="" || $price =="" || $type =="" ){
		    	$msg = "<span class='error'>Field must not be empty...!</span>";
					return $msg;
		    }else{
		    		if(!empty($file_name)){

				    if ($file_size >1048567) {
				      echo "<span class='error'>Image Size should be less then 1MB!
				     </span>";
				    } elseif (in_array($file_ext, $permited) === false) {
				      echo "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
				    }
				    else{
				    	  move_uploaded_file($file_temp, $uploaded_image);
				    	 $query = "UPDATE tbl_product 
				    	 	SET
				    	 	productName='$productName',
				    	 	catId='$catId',
				    	 	brandId='$brandId',
				    	 	body='$body',
				    	 	price='$price',
				    	 	image='$uploaded_image',
				    	 	type='$type' WHERE productId='$id' ";
						$productUpdate = $this->db->update($query);
						if($productUpdate){
							$msg = "<span class='success'>product Update Successfully...</span>";
							return $msg;
						}else{
							$msg = "<span class='error'>product Not Updated...!</span>";
							return $msg;
						}
				  	 }
				}else{

			    	 $query = "UPDATE tbl_product 
				    	 	SET
				    	 	productName='$productName',
				    	 	catId='$catId',
				    	 	brandId='$brandId',
				    	 	body='$body',
				    	 	price='$price',
				    	 	type='$type' WHERE productId='$id' ";
						$productUpdate = $this->db->update($query);
						if($productUpdate){
							$msg = "<span class='success'>product Update Successfully...</span>";
							return $msg;
						}else{
							$msg = "<span class='error'>product Not Updated...!</span>";
							return $msg;
						}
				}
			}
		}
	}
	public function delProById($id){
		$query = "SELECT * FROM tbl_product WHERE productId ='$id' ";
		$delProduct = $this->db->select($query);
		if($delProduct){
			while($delimg = $delProduct->fetch_assoc()){
				$dellink = $delimg['image'];
				unlink($dellink);
			}			
		}
		$delquery = "DELETE FROM tbl_product WHERE productId='$id' ";
		$delProductmsg = $this->db->delete($delquery);
		if($delProductmsg){
					$msg = "<span class='success'>Product Deleted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Product Not Deleted...!</span>";
					return $msg;
				}
	}

	public function getAllFpd(){
		$query = "SELECT * FROM tbl_product WHERE type = '0' ORDER BY productId DESC LIMIT 4";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function getAllNpd(){
		$query = "SELECT * FROM tbl_product WHERE type = '1' ORDER BY productId DESC LIMIT 4";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function getSinglePro($id){
		$query = "SELECT p.*,c.catName,b.brandName FROM tbl_product AS p,tbl_category AS c,tbl_brand AS b
			WHERE p.brandId = b.brandId AND p.catId = c.catId AND p.productId = '$id'";
			$getSinPro = $this->db->select($query);
			return $getSinPro;
	}
	public function getOneLatestIphone(){
		$query = "SELECT * FROM tbl_product WHERE brandId='9' ORDER BY productId DESC LIMIT 1";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function getOneLatestAsus(){
		$query = "SELECT * FROM tbl_product WHERE brandId='8' ORDER BY productId DESC LIMIT 1";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function getOneLatestHp(){
		$query = "SELECT * FROM tbl_product WHERE brandId='4' ORDER BY productId DESC LIMIT 1";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function getOneLatestCanon(){
		$query = "SELECT * FROM tbl_product WHERE brandId='7' ORDER BY productId DESC LIMIT 1";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function getCatById($id){
		$query = "SELECT * FROM tbl_product WHERE catId='$id' ";
		$getPro = $this->db->select($query);
		return $getPro;
	}
	public function insertProductToCompare($productId,$customerId){

		$query = "SELECT * FROM tbl_compare WHERE productId='$productId' AND customerId='$customerId'";
		$getCompare= $this->db->select($query);
		if($getCompare){
			$msg = "<span class='error'>Already added...!</span>";
				return $msg;
		}

		$productId = mysqli_escape_string($this->db->link,$productId);
		$customerId = mysqli_escape_string($this->db->link,$customerId);
		$query = "SELECT * FROM tbl_product WHERE productId='$productId'";
		$getProduct = $this->db->select($query);
		if($getProduct){
			while($result = $getProduct->fetch_assoc()){
				$productName = $result['productName'];
				$price = $result['price'];
				$image = $result['image'];

			$query = "INSERT INTO tbl_compare(customerId,productId,productName,price,image) VALUES ('$customerId','$productId','$productName','$price','$image')";
				$insertCompare = $this->db->insert($query);
				if($insertCompare){
					$msg = "<span class='success'>Compare added successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Compare not added...!</span>";
					return $msg;
				}
			}
		}
		
	}
	public function getCompareByCusId($customerId){
		$query = "SELECT * FROM tbl_compare WHERE customerId='$customerId'";
		$getCompare= $this->db->select($query);
		return $getCompare;
	}
	public function showCompareByCusId($cusId){
			$query = "SELECT * FROM tbl_compare WHERE customerId='$cusId'";
			$getCompare= $this->db->select($query);
			return $getCompare;
	}
	public function delcompareByCusId($cusid){
		$delquery = "DELETE FROM  tbl_compare WHERE customerId='$cusid' ";
		$delcompare = $this->db->delete($delquery);
	}
	public function insertProductToWishlist($id,$customerId){

		$productId = mysqli_escape_string($this->db->link,$id);
		$customerId = mysqli_escape_string($this->db->link,$customerId);
		$query = "SELECT * FROM tbl_wishlist WHERE productId='$productId' AND customerId='$customerId'";
		$getCompare= $this->db->select($query);
		if($getCompare){
			$msg = "<span class='error'>Already added...!</span>";
				return $msg;
		}	
		$query = "SELECT * FROM tbl_product WHERE productId='$productId'";
		$getProduct = $this->db->select($query);
		if($getProduct){
			while($result = $getProduct->fetch_assoc()){
				$productName = $result['productName'];
				$price = $result['price'];
				$image = $result['image'];

			$query = "INSERT INTO tbl_wishlist(customerId,productId,productName,price,image) VALUES ('$customerId','$productId','$productName','$price','$image')";
				$insertCompare = $this->db->insert($query);
				if($insertCompare){
					$msg = "<span class='success'>Wishlist added successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Not added...!</span>";
					return $msg;
				}
			}
		}
		
	}
	public function getwishlistByCusId($customerId){
		$query = "SELECT * FROM tbl_wishlist WHERE customerId='$customerId'";
		$getwislist= $this->db->select($query);
		return $getwislist;
	}
	public function showWishlistByCusId($cusId){
			$query = "SELECT * FROM tbl_wishlist WHERE customerId='$cusId'";
			$getCompare= $this->db->select($query);
			return $getCompare;
	}
	public function delProByWlistId($id,$cusId){
		$delquery = "DELETE FROM  tbl_wishlist WHERE productid='$id' AND customerId='$cusId' ";
		$delwlist = $this->db->delete($delquery);
	}
}
?>