<?php
	$filepath = realpath(dirname(__FILE__));
		include_once ($filepath."/../lib/Database.php");
		include_once ($filepath."/../helpers/Format.php");
?>

<?php
	Class Brand{
		private $db;
		private $fm;

		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function brandInsert($brandName){
			$brandName = $this->fm->validation($brandName);
			$brandName = mysqli_escape_string($this->db->link,$brandName);
			if(empty($brandName)){
				$insertMsg = "Field Must not be empty...!";
				return $insertMsg;
			}else{
				$query = "INSERT INTO tbl_brand (brandName) VALUES ('$brandName')";
				$brandInsert = $this->db->insert($query);
				if($brandInsert){
					$msg = "<span class='success'>Brand Inserted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Brand Not Inserted...!</span>";
					return $msg;
				}
		}
	}
	public function getAlldata(){
		$query = "SELECT * FROM tbl_brand ORDER BY brandId DESC";
		$getBrand = $this->db->select($query);
		return $getBrand;
	}
	public function getbrandById($id){
		$query = "SELECT * FROM tbl_brand WHERE brandId='$id' ";
		$getBrand = $this->db->select($query);
		return $getBrand;
	}
	public function brandUpdateById($id,$brandName){
			$brandName = $this->fm->validation($brandName);
			$brandName = mysqli_escape_string($this->db->link,$brandName);
			if(empty($brandName)){
				$updateMsg = "Field Must not be empty...!";
				return $updateMsg;
			}else{
				$query = "UPDATE tbl_brand SET
				brandName = '$brandName' WHERE brandId='$id'";
				$brandUpdate = $this->db->update($query);
				if($brandUpdate){
					$msg = "<span class='success'>Brand Updated Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Brand Not Updated...!</span>";
					return $msg;
				}
		}
	}
	public function delBrandById($id){
		$query = "DELETE FROM tbl_brand WHERE brandId='$id' ";
		$delCat = $this->db->delete($query);
		if($delCat){
					$msg = "<span class='success'>Brand Deleted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Brand Not Deleted...!</span>";
					return $msg;
				}
	}


}
