<?php
	$filepath = realpath(dirname(__FILE__));
		include_once ($filepath."/../lib/Database.php");
		include_once ($filepath."/../helpers/Format.php");
?>


<?php
	Class Category{
		private $db;
		private $fm;

		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function catInsert($catName){
			$catName = $this->fm->validation($catName);
			$catName = mysqli_escape_string($this->db->link,$catName);
			if(empty($catName)){
				$insertMsg = "Field Must not be empty...!";
				return $insertMsg;
			}else{
				$query = "INSERT INTO tbl_category (catName) VALUES ('$catName')";
				$catInsert = $this->db->insert($query);
				if($catInsert){
					$msg = "<span class='success'>Category Inserted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Category Not Inserted...!</span>";
					return $msg;
				}
		}
	}
	public function getAlldata(){
		$query = "SELECT * FROM tbl_category ORDER BY catId DESC";
		$getCat = $this->db->select($query);
		return $getCat;
	}
	public function getCatById($id){
		$query = "SELECT * FROM tbl_category WHERE catId='$id' ";
		$getCat = $this->db->select($query);
		return $getCat;
	}
	public function catUpdateById($id,$catName){
			$catName = $this->fm->validation($catName);
			$catName = mysqli_escape_string($this->db->link,$catName);
			if(empty($catName)){
				$updateMsg = "Field Must not be empty...!";
				return $updateMsg;
			}else{
				$query = "UPDATE tbl_category SET
				catName = '$catName' WHERE catId='$id'";
				$catUpdate = $this->db->update($query);
				if($catUpdate){
					$msg = "<span class='success'>Category Updated Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Category Not Updated...!</span>";
					return $msg;
				}
		}
	}
	public function delCatById($id){
		$query = "DELETE FROM tbl_category WHERE catId='$id' ";
		$delCat = $this->db->delete($query);
		if($delCat){
					$msg = "<span class='success'>Category Deleted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Category Not Deleted...!</span>";
					return $msg;
				}
	}
	public function getAllCat(){
			$query = "SELECT * FROM tbl_category ORDER BY catId DESC ";
			$getCat = $this->db->select($query);
			return $getCat;
	}

}
?>