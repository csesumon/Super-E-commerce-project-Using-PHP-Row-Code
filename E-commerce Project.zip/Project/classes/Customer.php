<?php
	$filepath = realpath(dirname(__FILE__));
		include_once ($filepath."/../lib/Database.php");
		include_once ($filepath."/../helpers/Format.php");
?>


<?php
	Class Customer{
		private $db;
		private $fm;

		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function customerInsert($data){
			$name = mysqli_escape_string($this->db->link,$data['name']);
			$city = mysqli_escape_string($this->db->link,$data['city']);
			$zip_code = mysqli_escape_string($this->db->link,$data['zip_code']);
			$e_mail = mysqli_escape_string($this->db->link,$data['e_mail']);
			$address = mysqli_escape_string($this->db->link,$data['address']);
			$country = mysqli_escape_string($this->db->link,$data['country']);
			$phone = mysqli_escape_string($this->db->link,$data['phone']);
			$password = mysqli_escape_string($this->db->link,md5($data['password']));
		
			
		if($name =="" || $city =="" || $zip_code=="" || $e_mail =="" || $address =="" || $country=="" || $phone =="" || $password=="" ){
		    	$msg = "<span class='error'>Field must not be empty...!</span>";
					return $msg;
			}

			$checkmailquery = "SELECT * FROM tbl_customer WHERE e_mail='$e_mail'LIMIT 1";
				$mailcheck = $this->db->select($checkmailquery);
				if($mailcheck!=false){
					$msg = "<span class='error'>Email already exist...!</span>";
					return $msg;
				}else{
					$query = "INSERT INTO tbl_customer(name,city,zip_code,e_mail,address,country,phone,password) VALUES ('$name','$city','$zip_code','$e_mail','$address','$country','$phone','$password') ";
				$customerInsert = $this->db->insert($query);
				if($customerInsert){
					$msg = "<span class='success'>Customer Registration Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Registration Not Successfully...!</span>";
					return $msg;
				}
			}
		}
		public function customerLogin($data){
			$email = mysqli_escape_string($this->db->link,$data['username']);
			$userpass = mysqli_escape_string($this->db->link,md5($data['userpass']));
			if(empty($email) or empty($userpass)){
				$msg = "<span class='error'>Field must not be empty...!</span>";
					return $msg;
			}
			$query = "SELECT * FROM tbl_customer WHERE e_mail='$email' AND password='$userpass'";
				$useraccess = $this->db->select($query);
				if($useraccess!=false){
					$result = $useraccess->fetch_assoc();
					Session::set("cusLogin","true");
					Session::set("cusId",$result['cusId']);
					Session::set("cusName",$result['name']);
					header('location:cart.php');
			}else{
				$msg = "<span class='error'>Email or password not matched...!</span>";
					return $msg;
			}
		}
		public function getCusById($customerId){
			$query = "SELECT * FROM tbl_customer WHERE cusId='$customerId'";
			$getCus = $this->db->select($query);
		return $getCus;
		}
		public function updateProfle($data){
			$name = mysqli_escape_string($this->db->link,$data['name']);
			$city = mysqli_escape_string($this->db->link,$data['city']);
			$zip_code = mysqli_escape_string($this->db->link,$data['zip_code']);
			$e_mail = mysqli_escape_string($this->db->link,$data['e_mail']);
			$address = mysqli_escape_string($this->db->link,$data['address']);
			$country = mysqli_escape_string($this->db->link,$data['country']);
			$phone = mysqli_escape_string($this->db->link,$data['phone']);

			if($name =="" || $city =="" || $zip_code=="" || $e_mail =="" || $address =="" || $country=="" || $phone ==""){
		    	$msg = "<span class='error'>Field must not be empty...!</span>";
					return $msg;
				}else{
					$query = "UPDATE tbl_customer 
				    	 	SET
				    	 	name='$name',
				    	 	city='$city',
				    	 	zip_code='$zip_code',
				    	 	e_mail='$e_mail',
				    	 	address='$address',
				    	 	country='$country',
				    	 	phone='$phone' LIMIT 1";
						$profileUpdate = $this->db->update($query);
						if($profileUpdate){
							$msg = "<span class='success'>Profile Update Successfully...</span>";
							return $msg;
						}else{
							$msg = "<span class='error'>Profile Not Updated...!</span>";
							return $msg;
						}
			}
		}
		public function getCusAddressById($id){
			$query = "SELECT * FROM tbl_customer WHERE cusId='$id'";
			$getCus = $this->db->select($query);
			return $getCus;
		}
	}
?>