<?php
	$filepath = realpath(dirname(__FILE__));
		include_once ($filepath."/../lib/Database.php");
		include_once ($filepath."/../helpers/Format.php");
?>
<?php
	Class Cart{
		private $db;
		private $fm;

		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}

		public function addToCart($quantity,$id){
			$quantity = $this->fm->validation($quantity);
			$quantity = mysqli_escape_string($this->db->link,$quantity);
		   $productId =  mysqli_escape_string($this->db->link,$id);
		   $sessionId = session_id();

		 $squery  = "SELECT * FROM tbl_product WHERE productId='$productId' ";
		 $result  = $this->db->select($squery)->fetch_assoc();
		$productName= $result['productName'];
		$price 		= $result['price'];
		$image 		= $result['image'];
		$chquery  = "SELECT * FROM tbl_cart WHERE productId='$productId' AND  sessionId='$sessionId' ";
		 $result  = $this->db->select($chquery);
		 if($result){
		 	$msg = "<span class='error'>Product Already Added...!</span>";
			return $msg;
		 }else{
		 $query = "INSERT INTO tbl_cart(sessionId,productId,productName,price,quantity,image) VALUES ('$sessionId','$productId','$productName','$price','$quantity','$image') ";
				$cartInsert = $this->db->insert($query);
				if($cartInsert){
					header('location:cart.php');
				}else{
					header('location:404.php');
			}	  
		 }
		}
		public function getCartInfo(){
			$sessionId = session_id();
		 $squery  = "SELECT * FROM tbl_cart WHERE sessionId='$sessionId'";
		 $result  = $this->db->select($squery);
		 return $result;
		}
		public function updateCartQuan($quantity,$cartId){
			$query = "UPDATE tbl_cart SET
				quantity = '$quantity' WHERE cartId='$cartId'";
				$catUpdate = $this->db->update($query);
				if($catUpdate){
					header('location:cart.php');
						exit();
				}else{
					$msg = "<span class='error'>Quantity Not Updated...!</span>";
					return $msg;
				}
		}
		public function delCartById($id){
		$query = "DELETE FROM tbl_cart WHERE cartId='$id' ";
		$delCat = $this->db->delete($query);
		if($delCat){
					$msg = "<span class='success'>Cart Deleted Successully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Cart Not Deleted...!</span>";
					return $msg;
				}
	}
	public function delCusBySession(){
		$sessionId = session_id();
		$query = "DELETE FROM tbl_cart WHERE sessionId = '$sessionId'";
		$this->db->delete($query);
	}
	public function insetOrderByCusId($cusId){
		$sessionId = session_id();
		 $squery  = "SELECT * FROM tbl_cart WHERE sessionId='$sessionId'";
		 $result  = $this->db->select($squery);
		 if($result){
		 	while($data = $result->fetch_assoc()){
		 		$productId 		= $data['productId'];
		 		$productName	= $data['productName'];
		 		$quantity 		= $data['quantity'];
		 		$price 		    = $data['price'] * $quantity;
		 		$image 		    = $data['image'];

		 		 $query = "INSERT INTO tbl_order(cusId,productId,productName,price,quantity,image) VALUES ('$cusId','$productId','$productName','$price','$quantity','$image')";
				$cartInsert = $this->db->insert($query);
		 	}
		 }
	}
	public function getPriceById($cusid){
		$squery  = "SELECT price FROM tbl_order WHERE cusId='$cusid' AND date =  now()";
		 $result  = $this->db->select($squery);
		 return $result;
	}
	public function getOrderInfo($customerId){
		$squery  = "SELECT * FROM tbl_order WHERE cusId='$customerId'ORDER BY productId DESC";
		 $result  = $this->db->select($squery);
		 return $result;
	}
	public function getAllOrderProduct(){
		$squery  = "SELECT * FROM tbl_order ORDER BY date";
		 $result  = $this->db->select($squery);
		 return $result;
	}
	public function updateStatusById($id,$price,$time){
			$id = mysqli_escape_string($this->db->link,$id);
			$price = mysqli_escape_string($this->db->link,$price);
			$time = mysqli_escape_string($this->db->link,$time);
			$query = "UPDATE tbl_order SET
				status = '1' WHERE cusId='$id' AND price='$price' AND date='$time' ORDER BY date";

				$orderUpdate = $this->db->update($query);
				if($orderUpdate){
					$msg = "<span class='success'>Updated Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Not Updated...!</span>";
					return $msg;
				}
	}
	public function delShiftedProduct($id,$price,$time){
			$id = mysqli_escape_string($this->db->link,$id);
			$price = mysqli_escape_string($this->db->link,$price);
			$time = mysqli_escape_string($this->db->link,$time);
		$query = "DELETE FROM tbl_order WHERE cusId='$id' AND price='$price' AND date='$time' ORDER BY date";
				$orderDelete = $this->db->delete($query);
				if($orderDelete){
					$msg = "<span class='success'>Data Deleted Successfully...</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Data Not Deleted...!</span>";
					return $msg;
				}
	}
	public function updateStatusByIdFrond($id,$price,$time){
		$id = mysqli_escape_string($this->db->link,$id);
		$price = mysqli_escape_string($this->db->link,$price);
		$time = mysqli_escape_string($this->db->link,$time);
				$query = "UPDATE tbl_order SET
				status = '2' WHERE cusId='$id' AND price='$price' AND date='$time' ORDER BY date";
				$orderUpdate = $this->db->update($query);
				return $orderUpdate;
				
	}
}