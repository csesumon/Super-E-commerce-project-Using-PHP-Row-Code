<?php include 'inc/header.php';?>
<?php include "../classes/Customer.php";?>
<?php include 'inc/sidebar.php';?>
<?php
    $cus = new Customer();
?>
<?php
    if(!isset($_GET['cusId']) || $_GET['cusId']==NULL){
        echo "<script> window.location='404.php';</script>";
    }else{
        $id = preg_replace('/[^-a-zA-Z0-9_]/','', $_GET['cusId']);
    }
?>
<?php
    if($_SERVER["REQUEST_METHOD"]=="POST"){
         echo "<script> window.location='inbox.php';</script>";
    }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Customer Address Details</h2>
               <div class="block copyblock"> 
               <?php
                    $getCus = $cus->getCusAddressById($id);
                    if($getCus){
                        while($result = $getCus->fetch_assoc()){
                ?>
             <form action="" method="post">
                <table class="form">                    
                    <tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['name'];?>" class="medium" />
                        </td>
                    </tr><tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['e_mail'];?>" class="medium" />
                        </td>
                    </tr><tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['phone'];?>" class="medium" />
                        </td>
                    </tr><tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['address'];?>" class="medium" />
                        </td>
                    </tr><tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['zip_code'];?>" class="medium" />
                        </td>
                    </tr><tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['city'];?>" class="medium" />
                        </td>
                    </tr><tr>
                        <td>
                            <input type="text" readonly = "readonly" value="<?php echo $result['country'];?>" class="medium" />
                        </td>
                    </tr>
                    <tr> 
                        <td>
                            <input type="submit" name="submit" Value="Save" />
                        </td>
                    </tr>
                </table>
          </form>
                    <?php  }}?>
                </div>
            </div>
        </div>

<?php include 'inc/footer.php';?>