﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
	$filepath = realpath(dirname(__FILE__));
		include_once ($filepath."/../classes/Cart.php");
		include_once ($filepath."/../helpers/Format.php");
?>
<?php  
	$ct = new Cart();
	$fm = new Format();

	if(isset($_GET['shiftedid'])){
		$id = $_GET['shiftedid'];
		$price = $_GET['price'];
		$time = $_GET['time'];
		$updateStatus = $ct->updateStatusById($id,$price,$time);
	}
	if(isset($_GET['delshiftedid'])){
		$id = $_GET['delshiftedid'];
		$price = $_GET['price'];
		$time = $_GET['time'];
		$delShifted = $ct->delShiftedProduct($id,$price,$time);
	}
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
                <?php 
                if(isset($updateStatus)){
                	echo $updateStatus;
                } if(isset($delShifted)){
                	echo $delShifted;
                }?>   
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>ID</th>
							<th>Order Time</th>
							<th>Product</th>
							<th>Price</th>
							<th>Quantity</th>
							<th>Address</th>
							<th>Cus ID</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
					<?php
					$ct = new Cart();
					$fm = new Format();
						$getOrder = $ct->getAllOrderProduct();
						if($getOrder){
							while($data = $getOrder->fetch_assoc()){
					?>
						<tr class="odd gradeX">
							<td><?php echo $data['orderId'];?></td>
							<td><?php echo $fm->formatDate($data['date'])?></td>
							<td><?php echo $data['productName'];?></td>
							<td><?php echo $data['price'];?></td>
							<td><?php echo $data['quantity'];?></td>
							<td><a href="customer.php?cusId=<?php echo $data['cusId'];?>">Address</a></td>
							<td><?php echo $data['cusId'];?></td>
							<td>
								<?php
									if($data['status']=='0'){?>
										<a href="?shiftedid=<?php echo $data['cusId'];?> & price=<?php echo $data['price'];?> & time=<?php echo $data['date'];?>">Shifted</a>
								<?php	} elseif($data['status']=='1'){?>
												Pending
								<?php }else{?>
									<a href="?delshiftedid=<?php echo $data['cusId'];?> & price=<?php echo $data['price'];?> & time=<?php echo $data['date'];?>">Remove</a>
								<?php }?>
							</td>
						</tr>
						<?php } }?>
					</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>
