<?php include "inc/header.php" ?>
<style>
.Payment{width:500px; margin: 0 auto; padding:50px 100px;border: 2px solid #ccc;text-align: center;min-height: 130px}
.Payment h2 { border-bottom: 1px solid #000; color: #6c6c6c; font-family: "Monda",sans-serif; font-size: 25px;
</style>
 <div class="main">
    <div class="content">
    	<div class="section group">
			<div class="Payment">
				<h2>Success</h2>
				<?php 
					$cusid = Session::get("cusId");
					$getPrice = $ct->getPriceById($cusid);
					if($getPrice){
						$sum = 0;
						while($data = $getPrice->fetch_assoc()){
							$price  = $data['price'];
							$sum = $sum+$price;
						}
					}
				?>
				<p>Total payable amount(including vat) :
				<?php
					$vat = $sum * 0.1;
					$total = $vat+$sum;
					echo $total;
				?>
				</p>
				<p>Thanks for purchase. Recfeive your order successfully. We will contact you ASAP with delivery details. Here is your order details...<a href="orderdetails.php">visit here</a></p>
			</div>			
 		</div>
 	</div>
</div>
<?php include "inc/footer.php"?>